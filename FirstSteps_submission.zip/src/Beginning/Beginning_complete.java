package Beginning;

public class Beginning_complete {}
