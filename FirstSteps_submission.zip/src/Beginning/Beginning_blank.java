package Beginning;

public class Beginning_blank {

    /* TODO: Write a Java class that prints "Welcome to COMP 210!"*/

}
