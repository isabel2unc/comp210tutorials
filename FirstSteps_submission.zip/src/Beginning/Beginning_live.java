package Beginning;

public class Beginning_live {}
