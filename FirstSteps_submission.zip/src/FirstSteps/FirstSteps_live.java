package FirstSteps;

public class FirstSteps_live {

    /* TODO: Write a Java class that prints "Welcome to COMP 210!" */
    //comment

    public int x = 10;
    private static String hello = "Welcome to COMP 210!";

    public static void main(String[] args){
        System.out.print("Welcome to COMP 210!");
        System.out.print(hello);
    }

}
